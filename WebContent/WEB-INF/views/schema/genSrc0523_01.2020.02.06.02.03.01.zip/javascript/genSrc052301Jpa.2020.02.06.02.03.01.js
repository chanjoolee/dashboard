		var genSrc052301Jpa = {
			"eAnnotations": {
				"details": {
					"_xmi:id": "_SmZlwkg2EeqonN_RS9oRzw",
					"_key": "uuid",
					"_value": "_co2B4H0hEemtbe7XArhuwQ",
					"__prefix": null
				},
				"_xmi:id": "_SmZlwUg2EeqonN_RS9oRzw",
				"_source": "genmymodel",
				"__prefix": null
			},
			"ownedEntities": [
				{
					"eAnnotations": {
						"details": {
							"_xmi:id": "_SmZlxUg2EeqonN_RS9oRzw",
							"_key": "uuid",
							"_value": "_oZZBAF9PEDek0JnbBus9EQ",
							"__prefix": null
						},
						"_xmi:id": "_SmZlxEg2EeqonN_RS9oRzw",
						"_source": "genmymodel",
						"__prefix": null
					},
					"properties": [
						{
							"eAnnotations": {
								"details": {
									"_xmi:id": "_SmZlyEg2EeqonN_RS9oRzw",
									"_key": "uuid",
									"_value": "_EGy8MV9QEDek0JnbBus9EQ",
									"__prefix": null
								},
								"_xmi:id": "_SmZlx0g2EeqonN_RS9oRzw",
								"_source": "genmymodel",
								"__prefix": null
							},
							"annotations": {
								"eAnnotations": {
									"details": {
										"_xmi:id": "_SmZly0g2EeqonN_RS9oRzw",
										"_key": "uuid",
										"_value": "_KJ0OkV9QEDek0JnbBus9EQ",
										"__prefix": null
									},
									"_xmi:id": "_SmZlykg2EeqonN_RS9oRzw",
									"_source": "genmymodel",
									"__prefix": null
								},
								"_xsi:type": "gmmjpa:Id",
								"_xmi:id": "_SmZlyUg2EeqonN_RS9oRzw",
								"__prefix": null
							},
							"type": {
								"_href": "http://www.eclipse.org/emf/2002/Ecore#//EString",
								"__prefix": null
							},
							"_xmi:id": "_SmZlxkg2EeqonN_RS9oRzw",
							"_name": "soruce_id",
							"_documentation": "<pre>\n<code class=\"language-json\">{\n\trequired : true\n}</code></pre>\n\n<p>&nbsp;</p>\n",
							"__prefix": null
						},
						{
							"eAnnotations": {
								"details": {
									"_xmi:id": "_SmZlzkg2EeqonN_RS9oRzw",
									"_key": "uuid",
									"_value": "_5fm7EV9PEDek0JnbBus9EQ",
									"__prefix": null
								},
								"_xmi:id": "_SmZlzUg2EeqonN_RS9oRzw",
								"_source": "genmymodel",
								"__prefix": null
							},
							"annotations": {
								"eAnnotations": {
									"details": {
										"_xmi:id": "_SmZl0Ug2EeqonN_RS9oRzw",
										"_key": "uuid",
										"_value": "_hH-ggF9dEDek0JnbBus9EQ",
										"__prefix": null
									},
									"_xmi:id": "_SmZl0Eg2EeqonN_RS9oRzw",
									"_source": "genmymodel",
									"__prefix": null
								},
								"_xsi:type": "gmmjpa:Id",
								"_xmi:id": "_SmZlz0g2EeqonN_RS9oRzw",
								"__prefix": null
							},
							"type": {
								"_href": "http://www.eclipse.org/emf/2002/Ecore#//EString",
								"__prefix": null
							},
							"_xmi:id": "_SmZlzEg2EeqonN_RS9oRzw",
							"_name": "gen_type",
							"_documentation": "<pre>\n<code class=\"language-json\">{\n\trequired : true\n}</code></pre>\n\n<p>&nbsp;</p>\n",
							"__prefix": null
						},
						{
							"eAnnotations": {
								"details": {
									"_xmi:id": "_SmZl1Eg2EeqonN_RS9oRzw",
									"_key": "uuid",
									"_value": "_2CtT8R5NEDiJl4vo7-ai9A",
									"__prefix": null
								},
								"_xmi:id": "_SmZl00g2EeqonN_RS9oRzw",
								"_source": "genmymodel",
								"__prefix": null
							},
							"annotations": {
								"eAnnotations": {
									"details": {
										"_xmi:id": "_SmZl10g2EeqonN_RS9oRzw",
										"_key": "uuid",
										"_value": "_P3zCoR5OEDiJl4vo7-ai9A",
										"__prefix": null
									},
									"_xmi:id": "_SmZl1kg2EeqonN_RS9oRzw",
									"_source": "genmymodel",
									"__prefix": null
								},
								"_xsi:type": "gmmjpa:Embedded",
								"_xmi:id": "_SmZl1Ug2EeqonN_RS9oRzw",
								"__prefix": null
							},
							"type": {
								"_href": "http://www.eclipse.org/emf/2002/Ecore#//EString",
								"__prefix": null
							},
							"_xmi:id": "_SmZl0kg2EeqonN_RS9oRzw",
							"_name": "db_type",
							"_documentation": "<pre>\n<code class=\"language-json\">{\n\trequired : true\n}</code></pre>\n\n<p>&nbsp;</p>\n",
							"__prefix": null
						},
						{
							"eAnnotations": {
								"details": {
									"_xmi:id": "_SmZl2kg2EeqonN_RS9oRzw",
									"_key": "uuid",
									"_value": "_oZa2MF9PEDek0JnbBus9EQ",
									"__prefix": null
								},
								"_xmi:id": "_SmZl2Ug2EeqonN_RS9oRzw",
								"_source": "genmymodel",
								"__prefix": null
							},
							"type": {
								"_href": "http://www.eclipse.org/emf/2002/Ecore#//EString",
								"__prefix": null
							},
							"_xmi:id": "_SmZl2Eg2EeqonN_RS9oRzw",
							"_name": "url",
							"__prefix": null
						}
					],
					"_xmi:id": "gensrc_list",
					"_name": "gensrc_list",
					"_documentation": "<pre>\n<code class=\"language-json\">{\n\tcustom_columns : [\n\t\t{\n\t\t\tcolumn_name : \"btn_exec\",\n\t\t\tcolumn_after : \"url\" ,\n\t\t\tproperties : {\n\t\t\t\tformatter : function(cellValue, options, rowObject){\n\t\t\t\t\tvar btnHtml = '&lt;button type=\"button\" class=\"btn btn-warning btn-sm\" onclick=\"entityDoc.customFunc.fn_generateClick(\\''+ options.rowId +'\\');\"&gt;Generate&lt;/button&gt;';\n\t\t\t\t\treturn btnHtml;\n\t\t\t\t},\n\t\t\t\talign: 'center'\n\t\t\t}\n\t\t}\n\t\n\t]\n\t, customFunc : {\n\t\tfn_generateClick : function(rowId){\n\t\t\tvar grid = $(\"#gensrcListGrid\");\n\t\t\tvar rowData = grid.getRowData(rowId);\n\t\t\t\n\t\t    var url = rowData.URL;\n\t\t    $.ajax({\n\t\t        url: url ,\n\t\t        // data: {sqlid: \"codegen.tables\",owner: $(\"#owner\").val()}, \n\t\t\t\tasync: false,\n\t\t\t\theaders:{\n\t\t\t\t\tauthorization : \"Bearer 1bb9a71d-3742-471e-8d0a-aaf68db4eab8\"\n\t\t\t\t},\n\t\t        success:  function(doc,result,response){\n\t\t            // console.log(response.responseText);\n\t\t            genmyModelxmi = response.responseText;\n\n\t\t\t\t\tvar config = {};\n\t\t\t\t\tconfig.skipEmptyTextNodesForObj = true;\n\t\t\t\t\t//config.arrayAccessForm = \"property\";\n\t\t\t\t\tconfig.stripWhitespaces = true;\n\t\t\t\t\tconfig.enableToStringFunc = false;\n\n\t\t\t\t\tvar x2js = new X2JS(config);\n\t\t            schema_bpmn =  x2js.xml_str2json(genmyModelxmi);\n\t\t            // fn_create_source();\n\t\t            generator = new Generator(schema_bpmn,rowData.GEN_TYPE);\n\t\t            generator.fn_source();\n\t\t            // generator.fn_fileSave();\n\t\t        }\n\t\t    });\n\t\t\t\n\t\t}\n\t}\n\n}</code></pre>\n\n<p>&nbsp;</p>\n",
					"__prefix": null,
					"sqlPreFix": ""
				},
				{
					"eAnnotations": {
						"details": {
							"_xmi:id": "_SmZl3Ug2EeqonN_RS9oRzw",
							"_key": "uuid",
							"_value": "_XiuJYF9QEDek0JnbBus9EQ",
							"__prefix": null
						},
						"_xmi:id": "_SmZl3Eg2EeqonN_RS9oRzw",
						"_source": "genmymodel",
						"__prefix": null
					},
					"properties": [
						{
							"eAnnotations": {
								"details": {
									"_xmi:id": "_SmZl4Eg2EeqonN_RS9oRzw",
									"_key": "uuid",
									"_value": "_XiuwcF9QEDek0JnbBus9EQ",
									"__prefix": null
								},
								"_xmi:id": "_SmZl30g2EeqonN_RS9oRzw",
								"_source": "genmymodel",
								"__prefix": null
							},
							"annotations": {
								"eAnnotations": {
									"details": {
										"_xmi:id": "_SmZl40g2EeqonN_RS9oRzw",
										"_key": "uuid",
										"_value": "_XiuwcV9QEDek0JnbBus9EQ",
										"__prefix": null
									},
									"_xmi:id": "_SmZl4kg2EeqonN_RS9oRzw",
									"_source": "genmymodel",
									"__prefix": null
								},
								"_xsi:type": "gmmjpa:Id",
								"_xmi:id": "_SmZl4Ug2EeqonN_RS9oRzw",
								"__prefix": null
							},
							"type": {
								"_href": "http://www.eclipse.org/emf/2002/Ecore#//EString",
								"__prefix": null
							},
							"_xmi:id": "_SmZl3kg2EeqonN_RS9oRzw",
							"_name": "table_name",
							"__prefix": null
						},
						{
							"eAnnotations": {
								"details": {
									"_xmi:id": "_SmZl5kg2EeqonN_RS9oRzw",
									"_key": "uuid",
									"_value": "_XivXgF9QEDek0JnbBus9EQ",
									"__prefix": null
								},
								"_xmi:id": "_SmZl5Ug2EeqonN_RS9oRzw",
								"_source": "genmymodel",
								"__prefix": null
							},
							"annotations": {
								"eAnnotations": {
									"details": {
										"_xmi:id": "_SmZl6Ug2EeqonN_RS9oRzw",
										"_key": "uuid",
										"_value": "_XivXgV9QEDek0JnbBus9EQ",
										"__prefix": null
									},
									"_xmi:id": "_SmZl6Eg2EeqonN_RS9oRzw",
									"_source": "genmymodel",
									"__prefix": null
								},
								"_xsi:type": "gmmjpa:Id",
								"_xmi:id": "_SmZl50g2EeqonN_RS9oRzw",
								"__prefix": null
							},
							"type": {
								"_href": "http://www.eclipse.org/emf/2002/Ecore#//EString",
								"__prefix": null
							},
							"_xmi:id": "_SmZl5Eg2EeqonN_RS9oRzw",
							"_name": "column_name",
							"__prefix": null
						}
					],
					"references": {
						"eAnnotations": {
							"details": [
								{
									"_xmi:id": "_SmZl7Eg2EeqonN_RS9oRzw",
									"_key": "uuid",
									"_value": "_XivXgl9QEDek0JnbBus9EQ",
									"__prefix": null
								},
								{
									"_xmi:id": "_SmZl7Ug2EeqonN_RS9oRzw",
									"_key": "child_columns",
									"_value": "table_name,column_name",
									"__prefix": null
								},
								{
									"_xmi:id": "_SmZl7kg2EeqonN_RS9oRzw",
									"_key": "parent_columns",
									"_value": "table_name,column_name",
									"__prefix": null
								}
							],
							"_xmi:id": "_SmZl60g2EeqonN_RS9oRzw",
							"_source": "genmymodel",
							"__prefix": null
						},
						"_xmi:id": "reference::gensrc_tab_cols::gensrc_cmm_use",
						"_name": "hawk_cmm_use",
						"_referencedEntity": "gensrc_cmm_use",
						"__prefix": null
					},
					"_xmi:id": "gensrc_tab_cols",
					"_name": "gensrc_tab_cols",
					"__prefix": null,
					"sqlPreFix": ""
				},
				{
					"eAnnotations": {
						"details": [
							{
								"_xmi:id": "_SmZl8Ug2EeqonN_RS9oRzw",
								"_key": "uuid",
								"_value": "_Xiv-kF9QEDek0JnbBus9EQ",
								"__prefix": null
							},
							{
								"_xmi:id": "_SmZl8kg2EeqonN_RS9oRzw",
								"_key": "isDictionaryDefine",
								"_value": "true",
								"__prefix": null
							},
							{
								"_xmi:id": "_SmZl80g2EeqonN_RS9oRzw",
								"_key": "categoryColumn",
								"_value": "code_category",
								"__prefix": null
							},
							{
								"_xmi:id": "_SmZl9Eg2EeqonN_RS9oRzw",
								"_key": "codeColumn",
								"_value": "code_id",
								"__prefix": null
							},
							{
								"_xmi:id": "_SmZl9Ug2EeqonN_RS9oRzw",
								"_key": "nameColumn",
								"_value": "code_nm",
								"__prefix": null
							}
						],
						"_xmi:id": "_SmZl8Eg2EeqonN_RS9oRzw",
						"_source": "genmymodel",
						"__prefix": null
					},
					"properties": [
						{
							"eAnnotations": {
								"details": {
									"_xmi:id": "_SmZl-Eg2EeqonN_RS9oRzw",
									"_key": "uuid",
									"_value": "_Xiv-kV9QEDek0JnbBus9EQ",
									"__prefix": null
								},
								"_xmi:id": "_SmZl90g2EeqonN_RS9oRzw",
								"_source": "genmymodel",
								"__prefix": null
							},
							"annotations": {
								"eAnnotations": {
									"details": {
										"_xmi:id": "_SmZl-0g2EeqonN_RS9oRzw",
										"_key": "uuid",
										"_value": "_Xiv-kl9QEDek0JnbBus9EQ",
										"__prefix": null
									},
									"_xmi:id": "_SmZl-kg2EeqonN_RS9oRzw",
									"_source": "genmymodel",
									"__prefix": null
								},
								"_xsi:type": "gmmjpa:Id",
								"_xmi:id": "_SmZl-Ug2EeqonN_RS9oRzw",
								"__prefix": null
							},
							"type": {
								"_href": "http://www.eclipse.org/emf/2002/Ecore#//EString",
								"__prefix": null
							},
							"_xmi:id": "_SmZl9kg2EeqonN_RS9oRzw",
							"_name": "code_category",
							"__prefix": null
						},
						{
							"eAnnotations": {
								"details": [
									{
										"_xmi:id": "_SmZl_kg2EeqonN_RS9oRzw",
										"_key": "uuid",
										"_value": "_Xiv-k19QEDek0JnbBus9EQ",
										"__prefix": null
									},
									{
										"_xmi:id": "_SmZl_0g2EeqonN_RS9oRzw",
										"_key": "name_column",
										"_value": "code_nm",
										"__prefix": null
									}
								],
								"_xmi:id": "_SmZl_Ug2EeqonN_RS9oRzw",
								"_source": "genmymodel",
								"__prefix": null
							},
							"annotations": {
								"eAnnotations": {
									"details": {
										"_xmi:id": "_SmZmAkg2EeqonN_RS9oRzw",
										"_key": "uuid",
										"_value": "_Xiv-lF9QEDek0JnbBus9EQ",
										"__prefix": null
									},
									"_xmi:id": "_SmZmAUg2EeqonN_RS9oRzw",
									"_source": "genmymodel",
									"__prefix": null
								},
								"_xsi:type": "gmmjpa:Id",
								"_xmi:id": "_SmZmAEg2EeqonN_RS9oRzw",
								"__prefix": null
							},
							"type": {
								"_href": "http://www.eclipse.org/emf/2002/Ecore#//EString",
								"__prefix": null
							},
							"_xmi:id": "_SmZl_Eg2EeqonN_RS9oRzw",
							"_name": "code_id",
							"__prefix": null
						},
						{
							"eAnnotations": {
								"details": {
									"_xmi:id": "_SmZmBUg2EeqonN_RS9oRzw",
									"_key": "uuid",
									"_value": "_Xiv-lV9QEDek0JnbBus9EQ",
									"__prefix": null
								},
								"_xmi:id": "_SmZmBEg2EeqonN_RS9oRzw",
								"_source": "genmymodel",
								"__prefix": null
							},
							"type": {
								"_href": "http://www.eclipse.org/emf/2002/Ecore#//EString",
								"__prefix": null
							},
							"_xmi:id": "_SmZmA0g2EeqonN_RS9oRzw",
							"_name": "code_nm",
							"__prefix": null
						}
					],
					"references": {
						"eAnnotations": {
							"details": [
								{
									"_xmi:id": "_SmZmCEg2EeqonN_RS9oRzw",
									"_key": "uuid",
									"_value": "_Xiv-ll9QEDek0JnbBus9EQ",
									"__prefix": null
								},
								{
									"_xmi:id": "_SmZmCUg2EeqonN_RS9oRzw",
									"_key": "child_columns",
									"_value": "code_category",
									"__prefix": null
								},
								{
									"_xmi:id": "_SmZmCkg2EeqonN_RS9oRzw",
									"_key": "parent_columns",
									"_value": "code_category",
									"__prefix": null
								}
							],
							"_xmi:id": "_SmZmB0g2EeqonN_RS9oRzw",
							"_source": "genmymodel",
							"__prefix": null
						},
						"_xmi:id": "reference::gensrc_cmm_cd::gensrc_cmm_use",
						"_name": "hawk_cmm_use",
						"_referencedEntity": "gensrc_cmm_use",
						"__prefix": null
					},
					"_xmi:id": "gensrc_cmm_cd",
					"_name": "gensrc_cmm_cd",
					"__prefix": null,
					"sqlPreFix": ""
				},
				{
					"eAnnotations": {
						"details": [
							{
								"_xmi:id": "_SmZmDUg2EeqonN_RS9oRzw",
								"_key": "uuid",
								"_value": "_Xiv-l19QEDek0JnbBus9EQ",
								"__prefix": null
							},
							{
								"_xmi:id": "_SmZmDkg2EeqonN_RS9oRzw",
								"_key": "isDictionaryUse",
								"_value": "true",
								"__prefix": null
							}
						],
						"_xmi:id": "_SmZmDEg2EeqonN_RS9oRzw",
						"_source": "genmymodel",
						"__prefix": null
					},
					"properties": [
						{
							"eAnnotations": {
								"details": {
									"_xmi:id": "_SmZmEUg2EeqonN_RS9oRzw",
									"_key": "uuid",
									"_value": "_Xiv-mF9QEDek0JnbBus9EQ",
									"__prefix": null
								},
								"_xmi:id": "_SmZmEEg2EeqonN_RS9oRzw",
								"_source": "genmymodel",
								"__prefix": null
							},
							"annotations": {
								"eAnnotations": {
									"details": {
										"_xmi:id": "_SmZmFEg2EeqonN_RS9oRzw",
										"_key": "uuid",
										"_value": "_Xiv-mV9QEDek0JnbBus9EQ",
										"__prefix": null
									},
									"_xmi:id": "_SmZmE0g2EeqonN_RS9oRzw",
									"_source": "genmymodel",
									"__prefix": null
								},
								"_xsi:type": "gmmjpa:Id",
								"_xmi:id": "_SmZmEkg2EeqonN_RS9oRzw",
								"__prefix": null
							},
							"type": {
								"_href": "http://www.eclipse.org/emf/2002/Ecore#//EString",
								"__prefix": null
							},
							"_xmi:id": "_SmZmD0g2EeqonN_RS9oRzw",
							"_name": "table_name",
							"__prefix": null
						},
						{
							"eAnnotations": {
								"details": {
									"_xmi:id": "_SmZmF0g2EeqonN_RS9oRzw",
									"_key": "uuid",
									"_value": "_Xiv-ml9QEDek0JnbBus9EQ",
									"__prefix": null
								},
								"_xmi:id": "_SmZmFkg2EeqonN_RS9oRzw",
								"_source": "genmymodel",
								"__prefix": null
							},
							"annotations": {
								"eAnnotations": {
									"details": {
										"_xmi:id": "_SmZmGkg2EeqonN_RS9oRzw",
										"_key": "uuid",
										"_value": "_Xiv-m19QEDek0JnbBus9EQ",
										"__prefix": null
									},
									"_xmi:id": "_SmZmGUg2EeqonN_RS9oRzw",
									"_source": "genmymodel",
									"__prefix": null
								},
								"_xsi:type": "gmmjpa:Id",
								"_xmi:id": "_SmZmGEg2EeqonN_RS9oRzw",
								"__prefix": null
							},
							"type": {
								"_href": "http://www.eclipse.org/emf/2002/Ecore#//EString",
								"__prefix": null
							},
							"_xmi:id": "_SmZmFUg2EeqonN_RS9oRzw",
							"_name": "column_name",
							"__prefix": null
						},
						{
							"eAnnotations": {
								"details": {
									"_xmi:id": "_SmZmHUg2EeqonN_RS9oRzw",
									"_key": "uuid",
									"_value": "_XiwloF9QEDek0JnbBus9EQ",
									"__prefix": null
								},
								"_xmi:id": "_SmZmHEg2EeqonN_RS9oRzw",
								"_source": "genmymodel",
								"__prefix": null
							},
							"type": {
								"_href": "http://www.eclipse.org/emf/2002/Ecore#//EString",
								"__prefix": null
							},
							"_xmi:id": "_SmZmG0g2EeqonN_RS9oRzw",
							"_name": "code_category",
							"__prefix": null
						}
					],
					"_xmi:id": "gensrc_cmm_use",
					"_name": "gensrc_cmm_use",
					"__prefix": null,
					"sqlPreFix": ""
				}
			],
			"_xmlns:xmi": "http://www.omg.org/XMI",
			"_xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance",
			"_xmlns:gmmjpa": "http://com.genmymodel.jpa/1.0",
			"_xmi:version": "2.0",
			"_xmi:id": "_SmZlwEg2EeqonN_RS9oRzw",
			"_name": "genSrc0523_01",
			"_url": "",
			"_user": "",
			"__prefix": "gmmjpa"
		};